# Tavri Gate 2 — Narrative & Asset Integrity Report

**Result: PASS for Tavri-specific static narrative/asset integrity.** The complete game remains unvalidated: the shared cross-route scenes are provisional and the required engine/browser tests cannot run before implementation. Tavri-specific reference freeze awaits the user's explicit approval of this packaged candidate.

## Verified evidence

- PASS — `scene_ids_unique`
- PASS — `scene_ids_complete`
- PASS — `dialogue_ids_unique`
- PASS — `choice_ids_unique`
- PASS — `choice_point_ids_unique`
- PASS — `tavri_expression_codes_approved`
- PASS — `every_tavri_line_has_expression`
- PASS — `all_expected_scenes_have_content`
- PASS — `all_assets_readable`
- PASS — `sprite_dimensions_match`
- PASS — `shared_scenes_explicitly_provisional`
- PASS — `each_choice_has_explicit_outcome`

- Defined scenes: **9** (7 Tavri, 2 provisional shared).
- Authored line IDs: **139**, all unique.
- Choice IDs: **16**, all unique; **6** choice points.
- Approved expression-state usage: **{'PLAYFUL': 15, 'ANNOYED': 6, 'SURPRISED': 10, 'WORRIED': 17, 'NEUTRAL': 18}**.
- Art: five **1024×1536 RGBA** sprites with transparent pixels, one **1448×1086 RGB** midpoint illustration, one **1448×1086 RGB** canonical sheet.
- SHA-256 checksums and approval status are recorded in the machine-readable manifest.

## Abstract route-feasibility proof (NOT an executed full game test)

| Route | Scenario | Candidate success day | Deliberate misses | Ordinary wrong answers | Failed midpoint | Failed finale |
|---|---|---:|---:|---:|---:|---:|
| Tavri | perfect | 15 | 0 | 0 | 0 | 0 |
| Tavri | recovery | 27 | 4 | 4 | 1 | 1 |
| Nerelle | perfect | 15 | 0 | 0 | 0 | 0 |
| Nerelle | recovery | 27 | 4 | 4 | 1 | 1 |
| Kaedra | perfect | 16 | 0 | 0 | 0 | 0 |
| Kaedra | recovery | 27 | 4 | 4 | 1 | 1 |

The abstract feasibility check follows approved weekday availability, three sequential action slots per day, one princess encounter per day, 11 necessary training sessions, one-slot encounters, and the recovery-heart accounting. It is **not** a replacement for scripted choice fixtures or the required independent state-space validator. See `abstract_route_scenarios.csv`.

## Remaining scope exclusions, cautions, and integration tasks

1. Historical narrative header reads DRAFT; use approval_record.md as authoritative approval metadata. Do not silently edit approved dialogue source.
2. Shared prologue and failure ending are provisional and excluded from the Tavri-specific reference freeze; they require cross-route approval before the **combined game content freeze**.
3. Ordinary 54-entry cross-route conversation catalog has not been authored; exact ordinary choice fixtures cannot yet be executed.
4. No runtime game engine, IndexedDB storage, browser deployment, or independent state-space search exists to execute full D-115/D-139 acceptance tests.
5. Five sprites have matching canvas dimensions and transparency but differ in poses; approval of exact production crop/registration behavior remains a UI/integration test, not a pixel-perfect guarantee.

## Manual editorial checks

- The seven Tavri scenes consistently use the approved fox-eared humanoid character and the theme of honesty beneath performance.
- Optional scenes have explicit one-time prerequisites and +2/+1/−1 half-heart outcomes, with narrative outcome IDs.
- Midpoint requires five hearts, Charisma 6 and Intelligence 4, with a shorter repeatable retry and no heart change.
- An ordinary or post-midpoint optional heart-earning action can trigger the linked final scene at ten projected hearts, with a single encounter transaction.
- The marriage epilogue doesn't add additional game time or heart rewards.
- The shared introductory and failure scenes have **not** been approved for use across the other two routes.

## Recommendation

Treat the seven Tavri scenes, approved character sheet, approved expression sprites, midpoint illustration, and text companion as a **Tavri reference-freeze candidate**. The user can explicitly authorize the Tavri-specific freeze independently of shared scenes. **Do not mark the whole three-route game content frozen** until the shared story text and the other two routes are approved. Later engine/browser validation remains mandatory before release.
