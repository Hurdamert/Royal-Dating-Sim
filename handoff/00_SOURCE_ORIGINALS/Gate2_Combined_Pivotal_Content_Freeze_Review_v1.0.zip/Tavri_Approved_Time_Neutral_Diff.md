# APPROVED external overlay — Tavri Unscripted Comedy

This is a four-line player-facing wording amendment approved after Tavri v1.0 was frozen. The original ZIP/source remains unchanged. Apply this overlay **only** when deriving the effective content for the future game.

```diff
--- frozen/TAV-EVT-POST-01
+++ approved-overlay/TAV-EVT-POST-01
@@ -1,3 +1,3 @@
-## E. Scene 4 — Unscripted Comedy Night
+## E. Scene 4 — Unscripted Comedy
 
 **Scene ID:** `TAV-EVT-POST-01`  
@@ -7,5 +7,5 @@
 **Objective:** Let Tavri choose imperfection without treating humor as something she must always provide.
 
-- `TAV-POST-001` NARRATOR: Someone in the Town Square has erected a tiny stage. A hand-painted sign announces: *Royal Comedy Evening: Participation Voluntary, Embarrassment Inevitable.*
+- `TAV-POST-001` NARRATOR: Someone in the Town Square has erected a tiny stage. A hand-painted sign announces: *Royal Comedy Showcase: Participation Voluntary, Embarrassment Inevitable.*
 - `TAV-POST-002` TAVRI [PLAYFUL]: "Excellent. Finally, an event whose organizers understand their audience."
 - `TAV-POST-003` PLAYER: "Are you performing?"
@@ -13,5 +13,5 @@
 - `TAV-POST-005` NARRATOR: Onstage, a wizard pulls a rabbit from a hat. The rabbit takes one look at the audience and pulls the wizard back inside.
 - `TAV-POST-006` PLAYER: "Tough act to follow."
-- `TAV-POST-007` TAVRI [WORRIED]: "The court expects me to be effortlessly brilliant. I don't want to be brilliant tonight. But I don't want to disappoint everyone, either."
+- `TAV-POST-007` TAVRI [WORRIED]: "The court expects me to be effortlessly brilliant. I don't want to be brilliant on command. But I don't want to disappoint everyone, either."
 - `TAV-POST-008` PLAYER: "What do you actually want?"
 - `TAV-POST-009` TAVRI [SURPRISED]: "That is becoming a rather dangerous question around you."
@@ -31,5 +31,5 @@
    - **Narrative outcome ID:** `TAV-POST-O-PUSHED`.
 3. `TAV-POST-C1-SHAME` **Explicitly offensive; net −1 half-heart**. PLAYER: "Backing out makes you look weak. A real princess wouldn't disappoint her audience."
-   - `TAV-POST-X01` TAVRI [ANNOYED]: "I was hoping I could be myself for an evening. Now I have another audience to disappoint."
+   - `TAV-POST-X01` TAVRI [ANNOYED]: "I was hoping I could be myself for once. Now I have another audience to disappoint."
    - `TAV-POST-X02` NARRATOR: She steps away from you and joins the crowd alone.
    - **Narrative outcome ID:** `TAV-POST-O-HURT`.
```

IDs, prerequisites, locations, heart outcomes, time cost, and retry rules are unchanged.
