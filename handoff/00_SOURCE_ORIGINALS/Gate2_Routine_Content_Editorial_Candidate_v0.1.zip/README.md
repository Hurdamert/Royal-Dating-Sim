# Royal Exceptions — Gate 2 Routine Content Editorial Candidate v0.1

This **NEW and UNAPPROVED** narrative package is submitted for human editorial review. It supplements — but does not replace, modify, or automatically expand — approved Gate 2 frozen pivotal and visual packages.

## Recommended reading order

1. `Editorial_Review_Notes.md` — artistic quality, pacing, branch semantics, decision prompts and boundaries.
2. `Ordinary_Conversations_54_CANDIDATE_v0.1.md` — complete self-contained Tavri/Nerelle/Kaedra routine-scene script catalog; every choice has an authored character reaction and exact net heart effect.
3. `Content_Index.csv` — filter by princess, pre/post stage and unique/fallback rotation.
4. `Routine_Support_Copy_CANDIDATE_v0.1.md` — 14 Humpty contextual Help passages, 12 square quips, 8 training descriptions, 12 status/feedback labels and 14 routine UI strings.
5. `Static_Content_Validation_Results.json` — automated source checks and archive hashes.
6. `Freeze_Boundary_Ledger.md` — approvals that remain authoritative and untouched.
7. `manifest.json` — SHA-256 record of all included editorial documents.

**No game engine implementation, source code, new character art, new backgrounds, reworked pivotal scenes, save mechanics, or implementation specification is included.** The script/validation tools used privately to check the text are deliberately not part of this review ZIP.

**Status:** Ready for editorial review; not approved or frozen until user confirmation.
