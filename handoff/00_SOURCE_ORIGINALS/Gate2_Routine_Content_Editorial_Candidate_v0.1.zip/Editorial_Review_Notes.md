# Gate 2 — Routine Content Editorial Review Notes v0.1

**Decision sought:** Approve, request edits, or approve separately the newly authored routine conversations and supporting copy. **No new content is automatically canonical or frozen.** This follows approval of the pivotal-content and reusable visual/content-contract freezes.

## Produced scope

| New content group | Number | Source |
|---|---:|---|
| Tavri ordinary scenes | 18 | `Ordinary_Conversations_54_CANDIDATE_v0.1.md` |
| Nerelle ordinary scenes | 18 | same |
| Kaedra ordinary scenes | 18 | same |
| One-time first-use entries | 36 | six per princess per narrative stage |
| Cyclic fallbacks | 18 | three per princess per narrative stage |
| Humpty free contextual Help texts | 14 | `Routine_Support_Copy_CANDIDATE_v0.1.md` |
| Humpty Town Square quips | 12 | same |
| Training activity descriptions | 8 | same |
| Generic feedback texts | 12 | same |
| Supporting UI labels/instructions | 14 | same |

All 54 conversations include a narrated opening, a small exchange, one consequential choice point, two always-visible reply options, a correct/ordinary-incorrect branch, and explicit net heart effects. Six scenes (one per princess and stage) also have an optional **always-visible, explicitly offensive** response. Scenes contain no proposed unlockable equipment, new skills, map nodes, or stat effects. All six stage pools are in deterministic first-use order and have three repeated fallback scenes.

## Editorial highlights

**Tavri — performance versus honesty.** `TAV-ORD-PRE-U04` questions rehearsed smiles without requiring the player to have read other Tavri material. `TAV-ORD-POST-U04` lets Tavri abandon a joke without consequence; the shift is consistent with her approved vulnerability arc. `TAV-ORD-POST-F03` can repeat without invoking an unobserved prior event.

**Nerelle — curiosity without dependency.** `NER-ORD-PRE-U05` contrasts water-current diagrams with modern graphs without disparaging either source of expertise. `NER-ORD-POST-U01` treats her council obligations as legitimate. `NER-ORD-POST-F01` reinforces her own authorship of identity. Every Nerelle encounter is staged in accessible water and uses no leg/transformation description.

**Kaedra — strength without theatrical violence.** `KAE-ORD-PRE-U03` praises preventing needless destruction rather than combat. `KAE-ORD-POST-U06` explores delegation without reducing her competence. `KAE-ORD-POST-F03` frames respectful disagreement as affection, not obedience. No pivotal Royal Trial content is rewritten.

## Human editorial checkpoints before approval

1. **Character voices:** Are Tavri's playful theatricality, Nerelle's reflective dry wit and autonomy, and Kaedra's composed deadpan both distinct and consistent with their frozen narrative packages?
2. **Relationship pacing:** Is the pre/post shift perceptible but self-contained? No routine scene may be a prerequisite for the midpoint or proposal.
3. **Choice semantics:** Do players intuitively understand why each response is correct or ordinary wrong? Check that the six offensive choices are unmistakably disrespectful, not merely awkward jokes.
4. **Compactness:** A basic scene contains four introductory lines and one character reaction per branch. Is that adequate for everyday romance pacing? The deliberate shortness makes them fit variable mobile viewport sizes, but the overall game may feel underwritten if every interaction is this concise.
5. **Fallback repetition:** The three repeatable scenes per character/stage contain no cumulative claims, but voice delivery and asset timing need a future manual playthrough.
6. **Help/save wording:** Humpty's hints distinguish free reading from action costs and avoid leaking hidden optional thresholds. The save/error copy should be re-reviewed when concrete technical error states are known, rather than used as a substitute for the formal save contract.
7. **Supporting UI tone:** Are the eight activity descriptions, short feedback strings, and first-run instructions readable and appropriately comic without implying new rules?

## Minor editorial limitations, not static blockers

- All 54 conversations use only **two mandatory response options**, with a third offensive reply in six selected scenes. The approved content bible permits this. No stat-gated correct option was authored. More complex choices would require a separately approved revision, not a silent runtime addition.
- Character interaction prose currently uses one reaction line per outcome. This is a deliberate compact baseline; editorial review may request additional nonmechanical dialogue while preserving IDs and branch effects.
- Broad scheduling neutrality avoids time-of-day references. The approved BG-PRES-01/02 interpretations remain authoritative; actual screenshot/sprite positioning is later UI QA, not guaranteed by this prose.
- Humpty quip presentation priority and error-state wiring are **not** defined by this narrative candidate; they remain future technical contract work.
- The `Static_Content_Validation_Results.json` checks are regex/source-integrity checks. They are **not** a live engine, accessibility, persistence, or mathematical route-reachability proof.

## Proposed decision boundary

Approve the **ordinary conversation catalog** and **supporting routine copy** separately or together after editorial review. Their approval would make these texts binding as additional static narrative content but would not by itself reopen/modify the three frozen character archives, rewrite the implementation specification, or authorize gameplay implementation.
