# Gate 2 — Preserved Freeze Boundaries and External Approval Ledger

## Already approved and unchanged

- Tavri frozen Gate 2 character-specific reference archive v1.0.
- Nerelle frozen Gate 2 character-specific reference archive v1.0; visual costume approval clarification remains separate.
- Kaedra frozen Gate 2 character-specific reference archive v1.0; original sheet/bible defines wings and tail, visual costume follows approved artwork, Royal Trial protagonist depiction noncanonical.
- Effective combined pivotal-content freeze: 21 princess-specific pivotal scenes plus separately approved original `CORE-PRO-01` and `CORE-FAIL-01` scenes, with the four exact approved time-neutral Tavri text-overlay substitutions. All originals remain unchanged.
- Gate 2 scoped reusable-content/visual-assets freeze: seven original 1672 × 941 approved background PNGs, the approved Royal Exceptions visual-system contract, the approved ordinary-dialogue content bible, plus approved BG-PRES-01 (cinematic/static daylight backgrounds; HUD time authoritative) and BG-PRES-02 (Nerelle staged in the right-side Royal Gardens canal water; protagonist on shore) clarifications.

## Not approved by default

- The 54 ordinary conversations, 14 Humpty Help texts, 12 Humpty Town Square comments, 8 activity descriptions, 12 feedback strings and 14 supporting UI snippets in **this new v0.1 editorial candidate**.
- The exact UI interaction wiring for copy, application code, final font binaries/licensing notices, actual accessibility and cross-browser QA, or any revision to the game implementation specification.

### Baseline archive checks

All three frozen character ZIPs were rehashed during this candidate validation and matched the previously pinned SHA-256 values. The approved reusable-assets ZIP was verified for ZIP structural integrity. No approved file was opened for write or changed in place.
