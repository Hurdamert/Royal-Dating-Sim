# Gate 2 — Seven Reusable Backgrounds: Final Freeze Review v1.0

**Review status:** TECHNICAL VALIDATION PASS; **awaiting user approval** of the external staging interpretations and scoped visual/content-contract freeze. This is not full-game implementation or release approval.

## 1. Frozen baseline respected

All three character-specific ZIP source archives still match their previously approved SHA-256 values; no frozen package was modified. The combined pivotal-content freeze remains independent and unchanged (23 pivotal/shared scenes, approved Tavri external text overlay and external visual precedence).

## 2. Background inventory and file checks

All **seven approved** background PNG files exist, were decoded and re-opened successfully, are RGB/opaque, share **1672 × 941 px** dimensions (approximately 16:9), contain no additional route/location files, and were copied without editing. Each original and copied asset has a SHA-256 identifier in `Approved_Background_Manifest.json`. The original Home source matches its earlier Gate 2 Home candidate byte-for-byte.

Automated QA: **70 / 70 passed**, **0 failed**. Duplicate screening (exact SHA-256 + approximate 64-bit dHash) found no exact or close scene duplicates. This heuristic does not establish IP originality. The contact sheet and 320-px framing sketches are *derived noncanonical review previews*, not game assets.

| ID | Canonical location | Visible story/training scope | Image QA |
|---|---|---|---|
| `home` | Protagonist’s Home | Rest; Charisma reading; Strength calisthenics | PASS |
| `town_square` | Town Square | Tavri Tuesday; Humpty text commentary; kindness litter; conversations | PASS |
| `royal_library` | Royal Library | Tavri Saturday; Intelligence books and oracle | PASS |
| `adventurers_guild` | Adventurers’ Guild | Kaedra Tuesday/Thursday; Strength training | PASS |
| `palace_court` | Palace Court | Kaedra Wednesday/Sunday; Tavri Thursday; ceremonial scenes | PASS |
| `royal_gardens` | Royal Gardens | Tavri Monday/Sunday; Kaedra Saturday; Nerelle Wednesday canal | PASS |
| `moonwater_quay` | Moonwater Quay | Nerelle Monday/Friday/Sunday; dockside events | PASS |

## 3. Composition and continuity assessment (manual visual review)

- **Home:** Personal bedroom/study, exercise room for calisthenics, with no separate office node. APPROVED.
- **Town Square:** Civic market/fountain; space for encounters and free Humpty text cameo. APPROVED.
- **Royal Library:** Books, desks, decorative magical globe; sufficient for intelligence activities and visits. APPROVED.
- **Adventurers' Guild:** Open-sided but visibly roofed guild training yard with nonlethal equipment. Use the one existing guild node, NOT a new outdoor training-ground location. APPROVED IMAGE; location interpretation is recorded for implementer.
- **Palace Court:** Formal throne/ceremony hall with extensive open staging floor. APPROVED.
- **Royal Gardens:** Garden terrace and canal water at screen-right; retaining Nerelle in the water while interacting with onshore player requires staging validation. APPROVED IMAGE; see BG-PRES-02.
- **Moonwater Quay:** Harbor water and descending stone waterside steps, suitable for Nerelle to remain aquatic. APPROVED.

No pre-placed principal characters appear. The approved images do not contain legible scripted narrative text or gameplay UI. A visual review of the seven approved paintings found a coherent light-stone, burgundy-banners, ornate timber, gold-accent, painterly fantasy architecture. Visual assessment is editorial, not a quantitative art-style pass.

## 4. Scoped approval questions (before background freeze)

**BG-PRES-01 — Reusable-image time of day.** Several approved images are daylight lit, particularly Moonwater Quay, even though princess visits include evening slots. Existing authorization says midpoint CG lighting may be cinematic; it does not explicitly govern *base location backgrounds*. Proposal: all seven approved static location paintings are atmospheric representations; the explicit in-game day/slot remains authoritative. No unapproved day/night variants or time restrictions are introduced. This external clarification requires approval.

**BG-PRES-02 — Royal Gardens mermaid staging.** The gardens image has a visible canal to image-right but does not show an obvious terrace-to-water ramp or near-side water-level platform. Proposal: stage Nerelle visually in the canal itself (screen-right) while the protagonist remains onshore, never implying a walkable tail or an eighth location. Keep the original image; placement/crop must be checked in desktop and mobile layout review. This interpretation requires approval and later layout QA; the painting alone does not prove the composition works.

**Font and final UI implementation scope.** The approved visual system chooses Cormorant Garamond and Source Sans 3 and palette tokens. This ZIP preserves the visual-system *source contract*, not font binaries (not shareable) or production UI. Accurate font-licensing notices, real responsive layouts, image crop testing, and actual WCAG 2.2 AA UI audits remain future integration deliverables. The demonstration sketches here use substitute available font glyphs and may not be mistaken for approved UI screens.

## 5. Contrast checks for selected approved opaque token pairs

| Foreground/background | Contrast | WCAG AA normal text 4.5:1 |
|---|---:|---|
| ink/parchment | 12.48:1 | YES |
| ink/paper | 14.07:1 | YES |
| muted-ink/paper | 7.42:1 | YES |
| burgundy/paper | 6.56:1 | YES |
| focus-teal/paper | 4.87:1 | YES |
| gold/parchment | 2.49:1 | NO — do not use for body text |

Opacity changes or images behind a text panel can invalidate these pairwise numbers. Gold is decorative, NOT a reliable text color on parchment. Numeric foreground/background tests are not a substitute for a tested implementation.

## 6. Exact scoped freeze boundaries

Upon user sign-off the *seven approved source PNGs*, their SHA-256 manifest, the already-approved **Royal Exceptions** visual-system tokens and layout intent, the previously approved **Ordinary Dialogue Content Bible v0.1**, and the two external clarifications can be frozen as a **reusable art + content-authoring-contract** set. No princess-specific source archive changes. No new mechanics/locations/people are authorized.

**Not included or falsely certified**: the actual 54 routine conversations (D-080 allows later agent authoring and editorial approval), all final Humpty hints/training/UI copy, final reusable interface screen design, font binaries, engine implementation, actual accessibility tests, full QA, or technical implementation specification. Consequently this package can be approved as a limited Gate 2 reusable visual/content-contract freeze, **not full-content or release freeze**.

## 7. Acceptance recommendation

Technical files are valid and complete for exactly the seven approved background locations. Recommend approving BG-PRES-01/BG-PRES-02 as recorded external interpretations, then freezing the scoped reusable background and approved visual/content authoring contracts without changing originals. If BG-PRES-02 is unacceptable, request a new separately approved garden revision rather than silently editing the approved image.
