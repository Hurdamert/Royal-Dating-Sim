# Kaedra — Gate 2 Reference Candidate v1.0

**Status: candidate for Kaedra-only freeze, NOT YET FROZEN.**

This archive contains unchanged source assets and source text previously approved in the conversation. The validation report, QA contact sheet, manifest, and abstract scenario CSV are newly created review artifacts. The original scene text and character bible are preserved byte-for-byte, including old candidate headers, to avoid silent edits to approved content.

## Contents

- `narrative/`: approved Kaedra v0.2 bible and v0.1 pivotal script
- `art/character_sheet.png`: approved Kaedra character sheet
- `art/sprites/`: five approved expression assets
- `art/events/kaedra_royal_trial.png`: approved midpoint illustration
- `review/validation_report.md`: static checks, evidence and limitations
- `review/approval_record.md`: approval boundaries and visual cautions
- `review/kaedra_sprite_contact_sheet.png`: *derived* resized review comparison; not a game sprite
- `review/kaedra_abstract_route_scenarios.csv`: schedule witnesses, **not** executable game tests
- `manifest.json`: hashes, inventories and review status

**Excluded:** shared prologue/failure ending, ordinary dialogue corpus, production background scenes, full game engine, and final implementation specification.
