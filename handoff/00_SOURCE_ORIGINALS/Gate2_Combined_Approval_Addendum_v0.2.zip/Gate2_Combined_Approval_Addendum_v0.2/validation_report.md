# Gate 2 combined external addendum — validation report

## Checks run

1. **Frozen archive integrity:** Verified all three v1.0 archive SHA-256 hashes against the prior combined-review ledger before and after writing this addendum. All unchanged.
2. **Shared content:** Copied the prologue and failure sections directly from the frozen Tavri narrative source, preserving the eight `CORE-PRO` and six `CORE-FAIL` speaker/narration lines and all identifiers. Historical “unapproved/proposed” annotations remain verbatim in the excerpt but are superseded as approval labels by an explicit external wrapper.
3. **Time-neutral amendment candidate:** Applied the title and three precisely identified line-level text replacements to an **in-memory excerpt**, and generated a diff. No frozen source was edited.
4. **Identifiers:** The amended excerpt retains original ordered stable IDs for all scene, lines, choices, and narrative outcomes; no action or reward metadata was changed.
5. **Temporal text:** The amended excerpt contains neither “tonight” nor “evening”. No schedule restriction or time jump was introduced.
6. **External clarifications:** Cinematic midpoint lighting and previously approved visual-precedence interpretations documented separately.

## Deliberate limitations

- This is a static approval/integrity addendum, not independent game-engine execution, browser testing, or state-space reachability validation.
- The Tavri amended exact text remains an **editorial candidate** despite approval of the time-neutral direction; human line-level approval is needed before considering the combined pivotal content reconciled.
- The shared scenes were approved as originally written; this addendum has **not** revised their dialogue to remove historic candidate-status prose that is outside player-visible lines.
- Full game-content readiness is not established: 54 ordinary conversations, seven reusable location backgrounds, font/UI tokens, routine flavor text, and executable gameplay tests are not included.

## Verified frozen archive hashes

- `Tavri_Gate2_Review_Candidate_v1.0.zip`: `2b6c67e71f079dbfcaa4bf67b4ef2e3285fa767805d6b6d523edaf2ecb67aad5`
- `Nerelle_Gate2_Review_Candidate_v1.0.zip`: `06d60c9225509cda51ce7c4eb30909caea0914172f4a63d5155f5e4b3eedcadf`
- `Kaedra_Gate2_Review_Candidate_v1.0.zip`: `5a639ec0d0d1456a08b3bd7691c0a79eac2286b6ebd78db191940863f8410d21`
