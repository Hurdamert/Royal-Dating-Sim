# Gate 2 — Remaining Handoff Requirements Audit v1.0

**Scope:** Technical/editorial handoff-readiness audit only, following explicit approval of *both* Routine Content Editorial Candidate v0.1 components. This document is **not** a rewritten implementation specification, executable test harness, gameplay code, or final release certificate.

## Executive finding

**The authored Gate 2 narrative set is editorially complete:** 21 princess-specific pivotal scenes plus two approved shared scenes, 54 ordinary conversations, 7 location backgrounds, 15 expression sprites, 3 midpoint CGs, and the approved text-only Humpty/training/UI copy. Pivotal content, character reference ZIPs, reusable assets, visual-system contract and routine content bible are already frozen; routine source texts are now separately approved. No frozen source was modified for this report.

**An autonomous Goldfish coding handoff should not proceed solely on these creative archives.** The critical remaining issue is consolidating mechanically precise, conversation-independent instructions and validating the progression model. Technical contracts and executable verification belong to a **subsequent** gate, not this request.

## Readiness matrix

| ID | Priority | Outstanding item | Readiness |
|---|---|---|---|
| H-01 | HIGH | Effective content registry and immutable IDs | OPEN |
| H-02 | HIGH | Authoritative D-001–D-144 Gate 1 decision archive | NOT VERIFIED |
| H-03 | HIGH | Formal deterministic state/action/transition contract | OPEN |
| H-04 | HIGH | Save/import/export/locking/recovery contract | OPEN |
| H-05 | HIGH | Balance fixtures and independent reachability | NOT VERIFIED |
| H-06 | HIGH | Final representative visual-novel UI reference | OPEN |
| H-07 | MEDIUM | Content presentation/trigger and fallback rules | OPEN |
| H-08 | MEDIUM | Complete error and accessibility copy states | PARTIAL |
| H-09 | MEDIUM | Asset licensing, descriptions and font packaging | PARTIAL |
| H-10 | HIGH | Cross-route full content reconciliation | PARTIAL |
| H-11 | HIGH | Full Gate 2 consolidated approval/freeze | AWAITING FUTURE APPROVAL |
| H-12 | HIGH | Goldfish handoff acceptance and test criteria | OPEN |
| V-01 | LATER | Cross-browser UI/accessibility execution | NOT STARTED |
| V-02 | LATER | Save/load transaction and migration runtime tests | NOT STARTED |
| V-03 | LATER | Final integrated editorial playthrough and production asset QA | NOT STARTED |

### A. Must resolve or verify before independent Goldfish handoff

**H-01 — Canonical effective-content register.** A coder must know which exact files are authoritative without reading this chat or reconciling old `CANDIDATE` headings. Register each of the 23 effective pivotal/shared scenes only once, all 54 routine scenes, activity/Help/UI text IDs, the approved Tavri overlay, all seven location IDs, five expressions per princess, their midpoint CGs and bibles, and immutable SHA-256 hashes. The shared scenes are embedded in the Tavri narrative but must not appear twice. This approval ledger is an input to — not a replacement for — that registry.

**H-02 — Gate 1 design decision provenance.** Gate 2 source records refer to 144 accepted Gate 1 decisions and later external approvals. I cannot establish from the inspected creative ZIPs that a comprehensive, authoritative D-001 through D-144 register and resolution order is bundled for a fresh-context agent. **Verify existence or collect it as an explicit handoff input**; do not reconstruct missing decisions by guesswork.

**H-03 / H-04 — Formal gameplay and persistence contracts.** The stories describe heartbeat/slot interactions but are not a formal transition schema. Precise rules must cover three daily slots, the 28-day hard stop, half-heart integer accounting, stat sessions, 5-heart cap, stage gating, optional events, wrong/offensive effects, one-per-day encounters, midpoint/finale retries, and the instant proposal sharing the parent transaction. Include save snapshot boundaries, journals, import/export, multi-tab read-only mode, migration and recovery. The approved support copy explicitly defers exact error states; do not infer them from prose.

**H-05 — Independent balance and reachability.** Abstract perfect-run (Day 15/16) and recovery-run (Day 27) witnesses have been described, but not certified by an independently executed exhaustive/constraint reachability process. Concrete choices now exist, making accurate fixtures possible without inventing fallback dialogue. Verify all princess schedules and prerequisite training are satisfiable by Day 28, including last-evening behavior and nonwinning branches. This audit did not run simulation or live-engine tests.

**H-06 — Final representative UI acceptance references.** The approved *Royal Exceptions* typography/palette and painted scenes are sufficient stylistic guidance, but do not themselves settle responsive composition. Freeze reference layouts for desktop and 320px mobile with real sprites, captions, time HUD, choice stacks, focus treatment, control sizes, and dialogs. Specifically test Nerelle staged **in screen-right canal water** in Royal Gardens, and appropriate crop around dragon horns/fox ears/mermaid tail; no extra location or body transformation. Gold trim is decorative: previous nominal foreground/background contrast tests found 2.49:1 on parchment, below AA body-text requirements.

**H-07 / H-08 — Routine state-driven copy wiring.** The approved ordinary entries identify first-use/fallback pools and exact choice effects, but cursor persistence, display selection, and shared parent transaction need operational contracts. Humpty's 14 Help passages and 12 Town Square quips are **copy**, not permission for a new action, schedule or mechanic. Quip priority/trigger is unspecified; error/migration/import/locked-tab copy needs mapping to actual UI states. Keep all existing approved text unchanged; new or altered player-facing lines require separate editorial signoff.

**H-09 — Asset metadata and release packaging.** Keep source PNGs unchanged; prepare descriptive accessible text for all key images, font-license notices for approved Cormorant Garamond and Source Sans 3, optimized runtime derivatives, transparent sprite alpha verification, 16:9/320px crop rules, and original-art records. Browser/network/font availability behavior remains a technical design matter.

**H-10 / H-11 — Final integration and scope freeze.** Static pivotal review previously passed 74/74 and routine review 56/56. They cover different approved bundles and are not automatically a single effective merged-source test. Validate the merged registry for ID collisions, every narrative outcome resolution and all contextual constraints. Request **separate explicit user approval** for the eventual full Gate 2 effective-content/asset freeze, preserving all frozen ZIPs byte-for-byte.

**H-12 — Independent handoff acceptance.** A future goldfish agent must be able to implement from a signed, self-contained decision/contract/asset/test package with no chat dependency. Acceptance criteria need executable fixtures, visual acceptance references, error handling and negative-path cases, and versioned authority rules. Do not infer user authorization to code from editorial approval.

### B. Later implementation and release verification — not reasons to reopen creative freezes

- **V-01:** Browser-level WCAG 2.2 AA checks, keyboard/screen-reader/motion/320px acceptance and screen text contrast in actual rendered UI.
- **V-02:** Actual IndexedDB, atomic transactions, failure recovery, second-tab Web Locks, save import/export/migration and persistence regression tests.
- **V-03:** Integrated story/playthrough editorial QA, repeatable fallback readability, princess portrait compositing, actual asset compression and image load fallbacks.

These must eventually pass but cannot be claimed from source-only content validation. The frozen scripts and images need not change for the implementation to test them.

## Safely delegated vs approval-sensitive work

| Safely preparable in future design/handoff gate | Requires renewed user/editorial approval if altered |
|---|---|
| Exact metadata registry, deterministic fixture design, source-hash references, complete error-state mapping proposals, criteria/test descriptions | Any changes to existing 54 scenes, Humpty/support text, three pivotal routes, shared scenes, four-string Tavri overlay, artwork, title, visual tokens or game mechanics |
| Create optimized derivative assets with fidelity tests (without touching source originals) | Replacing approved backgrounds, introducing eighth location, adding character art or Humpty sprite, granting new training/stat/affinity effects |
| Build implementation architecture *after explicit authorization* and separate technical handoff approval | Inferring missing D-001–D-144 rules or silently changing canonical source precedence |

## Recommended sequence and stop point

1. **Now:** Retain this external approval ledger and audit with checksums; do not edit old source bundles.
2. **Next review task:** Verify the entire Gate 1 decision source exists. Draft a single effective content/asset manifest and reconcile all IDs; produce real UI reference compositions using previously approved art, if not already approved elsewhere.
3. **Before asking a Goldfish to build:** Complete or link machine-precise gameplay/persistence contracts plus independent Day 28 progression fixtures; obtain fresh-context review and explicit handoff signoff.
4. **After implementation authorization:** Execute engine, browser, accessibility, performance, save/error and complete integrated editorial QA.

**Verdict:** **Routine editorial approval COMPLETE.** **Full independent-agent handoff NOT YET VERIFIED / NOT YET AUTHORIZED.** The remaining obstacles are source-of-truth consolidation, formal contract completeness, UI acceptance references and independent progression testing — not missing romance scenes or an eighth location.
