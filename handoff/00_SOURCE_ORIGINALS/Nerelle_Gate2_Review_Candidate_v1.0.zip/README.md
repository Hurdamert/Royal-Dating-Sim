# Nerelle Gate 2 Reference Candidate v1.0

Human-approved Nerelle-specific assets and narrative, assembled unchanged into a review-ready source package. This candidate is not yet frozen.

- `art/character_sheet.png`: approved canonical illustrated reference.
- `art/sprites/nerelle_*.png`: approved five sprite expressions.
- `art/events/nerelle_forbidden_journey.png`: approved midpoint illustration.
- `narrative/Nerelle_Gate2_Narrative_Package_v0.1.md`: approved seven pivotal scenes, original file unchanged.
- `narrative/Nerelle_Gate2_Character_Bible_Candidate_v0.1.md`: approved written identity, original file unchanged.
- `review/validation_report.md`: automated checks, narrative findings, remaining limitations.
- `review/approval_record.md`: provenance of individual approvals and exclusion of shared scenes.
- `review/nerelle_sprite_contact_sheet.png`: review montage, not a production game asset.
- `review/nerelle_abstract_route_scenarios.csv`: day/slot examples, not a complete executable game test.
- `manifest.json`: exact SHA-256 for source assets and validation status.

**Review action:** choose whether the approved artwork is the controlling costume reference despite the older bible describing more modest coverage / restrained jewelry, and explicitly authorize or withhold Nerelle-only package freeze.
